// script.js
const gameBoard = document.getElementById('game-board');
const restartButton = document.getElementById('restart');

const cardValues = ['🍎', '🍌', '🍓', '🍇', '🍒', '🍍', '🥝', '🍉',
                    '🍎', '🍌', '🍓', '🍇', '🍒', '🍍', '🥝', '🍉'];
let flippedCards = [];
let matchedPairs = 0;
let moves = 0;
let timeLeft = 20; // 20-second timer
let timerId;

// Update moves and time
const movesDisplay = document.getElementById('moves');
const timerDisplay = document.getElementById('timer');

// Shuffle cards
function shuffle(array) {
  return array.sort(() => Math.random() - 0.5);
}

// Create cards
function createCards() {
  const shuffledValues = shuffle(cardValues);
  shuffledValues.forEach(value => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.setAttribute('data-value', value);

    card.innerHTML = `
      <div class="card-inner">
        <div class="card-front">${value}</div>
        <div class="card-back"></div>
      </div>
    `;

    card.addEventListener('click', () => handleCardClick(card));
    gameBoard.appendChild(card);
  });
}

// Handle card click
function handleCardClick(card) {
  if (card.classList.contains('flipped') || flippedCards.length === 2 || timeLeft <= 0) {
    return;
  }

  card.classList.add('flipped');
  flippedCards.push(card);

  if (flippedCards.length === 2) {
    moves++;
    movesDisplay.textContent = moves;
    checkMatch();
  }

  // End game if moves exceed limit
  if (moves > 20) {
    clearInterval(timerId);
    alert('Too many moves! Game Over.');
  }
}

// Check for a match
function checkMatch() {
  const [card1, card2] = flippedCards;
  const value1 = card1.getAttribute('data-value');
  const value2 = card2.getAttribute('data-value');

  if (value1 === value2) {
    matchedPairs++;
    flippedCards = [];

    if (matchedPairs === cardValues.length / 2) {
      clearInterval(timerId); // Stop timer on win
      setTimeout(() => alert('You Win!'), 300);
    }
  } else {
    setTimeout(() => {
      card1.classList.remove('flipped');
      card2.classList.remove('flipped');
      flippedCards = [];
    }, 1000);
  }
}

// Start the timer
function startTimer() {
  clearInterval(timerId); // Clear any existing timer
  timerId = setInterval(() => {
    timeLeft--;
    timerDisplay.textContent = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(timerId);
      alert('Time’s up! Game Over.');
    }
  }, 1000);
}

// Restart game
function restartGame() {
  gameBoard.innerHTML = '';
  flippedCards = [];
  matchedPairs = 0;
  moves = 0;
  timeLeft = 20; // Reset timer
  movesDisplay.textContent = moves;
  timerDisplay.textContent = timeLeft;
  clearInterval(timerId);
  createCards();
  startTimer(); // Restart the timer
}

// Initialize game
restartButton.addEventListener('click', restartGame);
createCards();
startTimer(); // Start the game with a timer
